Final - Generative Color Art
I decided to use expand on my midterm project for my final. I added the speech library which is pretty cool. I wanted to take my art piece further by allowing the voice to control it. 

Interface: Colored transparent boxes drawn on illustrator. Text reading "Say something." 

Input: 
    - Voice (Say anything)
    - Refresh Page to start over 

Output:
    - Specific color box appears for each letter/word spoken creating an art piece
    - Specific color box disappers & "Say Anything" appears 

Psuedocode: 
    - Add speech library
    - Speech recording variable
    - Draw rectangles
    - Put rectangles in a For loop
    - Add "Say Something" text 
    - ShowResult function 
    
    - Program says "Say Something"
    - Users says "Hello"
    - Need H-E-L-L-O to connect to specific rectangles
    - Combination art peice pops up 
    
    
    
    
    


